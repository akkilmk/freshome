from django.apps import AppConfig


class TwofaConfig(AppConfig):
    name = 'twofa'
