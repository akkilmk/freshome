from django.apps import AppConfig


class PhoneVerificationConfig(AppConfig):
    name = 'phone_verification'
